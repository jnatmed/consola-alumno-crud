export interface Ialumno {
	nombre: string;
	apellido: string;
	email: string;
	telefono: string;
	activo: boolean;
	fechaIngreso: string;
}
